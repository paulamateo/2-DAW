var heart = document.querySelectorAll('.heart');
var heart_2 = document.querySelectorAll('.heart_2');

heart.forEach((el)=> {
    el.addEventListener("click", (el)=> {
        el.target.nextElementSibling.classList.add("active");
        let product_title = document.getElementById('titulo_item').textContent;
        alert("Producto: " + product_title); //POP UP ELEMENTO 
    });
});

heart_2.forEach((el)=> {
    el.addEventListener("click", (el)=> {
        el.target.classList.remove("active");
    });
});