// console.log("Hola mundo desde Node.js");

// function test() {
//     var nombre = "John";
//     var edad = 38;
//     console.log('Hola ' + nombre + ', tienes ' +edad+ ' años');
// }

// test();


"use strict"
let x = 10
// console.log('valor de X ' +x);
console.log(`valor de X ${x}`);