window.onload = function(e) {
    console.log('documento cargado')

    // document.getElementsByTagName('h1')[0].innerText = 'Changed from JS!!'
}