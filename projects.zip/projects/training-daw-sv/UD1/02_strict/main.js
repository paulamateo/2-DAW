x = 10

console.log('el valor de X ' + x)