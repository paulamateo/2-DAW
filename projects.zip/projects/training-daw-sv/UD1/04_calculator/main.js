// Declarar 2 variables con número e imprimir por consola (mediante console.log()) el valor de:
// Suma
// Resta
// Multiplicación
// División


// define variables
let x, y;
x = 2;
y = 1;

// print sum, substract, multiply and divide
console.log( `La suma es ${x+y}, la resta es ${x-y}, la multiplicacion es ${x*y} y la division es ${x/y}`);