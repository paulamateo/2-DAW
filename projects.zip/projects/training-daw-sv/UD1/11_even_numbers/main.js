function evenNumbers() {

}

evenNumbers();
// expected output 2,4,6,8,10......98