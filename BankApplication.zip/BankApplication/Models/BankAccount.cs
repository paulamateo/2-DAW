using System.Text.Json;
namespace Models;

public class BankAccount {
    public string Number { get; }
    public string Owner { get; set; }
    private List<Transaction> transactions = new List<Transaction>();
    private static int accountNumber_seed = 1000;
    public decimal Balance {
        get {
            decimal balance = 0;
            foreach (Transaction item in transactions) {
                balance += item.Amount;
            }
            return balance;
        }
    }

    public BankAccount(string owner, decimal initialBalance) {
        Number = accountNumber_seed.ToString();
        Owner = owner;
        MakeDeposit(initialBalance, DateTime.Now, "First deposit");
        accountNumber_seed++;
    }

    public  void MakeDeposit(decimal amount, DateTime date, string note) {
        if (amount <= 0) {
            throw new ArgumentOutOfRangeException(nameof(amount), "El depósito debe ser positivo.");
        }
        var deposit = new Transaction(amount, date, note);
        transactions.Add(deposit);
        SaveTransactionsJson();
    }

    public void MakeWithdrawal(decimal amount, DateTime date, string note) {
        if (amount <= 0) {
            throw new ArgumentOutOfRangeException(nameof(amount), "No puedes quitar un depósito negativo."); //por teclado: -100
        }

        if ((Balance - amount) < 0) {
            throw new InvalidOperationException("No puedes sacar dinero de donde no hay.");
        }
        var withdrawal = new Transaction(-amount, date, note);
        transactions.Add(withdrawal);
        SaveTransactionsJson();
    }
    
    public string GetBalance() {
        return $"Tienes {Balance}€ en tu cuenta, {Owner}.";
    }
     public string GetNumberAccount() {
        return $"{Owner}\t\t{Number}";
    }
    public string GetAllAcounts() {
        return $"{Owner}\t\t{Balance}€\t{Number}";
    }

    public void GetTransactions() {
        if (LoadTransactionsJson()) {
            decimal currentBalance = 0;
            foreach (var transaction in transactions) {
                currentBalance += transaction.Amount;
                Console.WriteLine($"{transaction.Date.ToShortDateString()}\t{transaction.Amount}\t{currentBalance}\t{transaction.Note}");
            }
        }
    }

    public virtual void PerformMonthlyOperation() { }

    public override string ToString() {
        return Owner ?? "No Owner";
    }

    public void SaveTransactionsJson() {
        UtilsJSON.SaveJson($"{Number}.json", transactions);
    }

    public bool LoadTransactionsJson() {
        List<Transaction> loadedTransactions = UtilsJSON.LoadJson($"{Number}.json");
        if (loadedTransactions.Count > 0) {
            transactions = loadedTransactions;
            return true;
        }
        return false;
    }

    // public void SaveTransactionsToJSON() { //GUARDA LAS TRANSACCIONES EN ARCHIVOS JSON (ESCRIBIR)
    //     string json = JsonSerializer.Serialize(transactions);
    //     File.WriteAllText($"{Number}.json", json);
    // }

    // public bool LoadTransactionsFromJSON() { //CARGAR LAS TRANSACCIONES (LEER)
    //     try {
    //         string json = File.ReadAllText($"{Number}.json");
    //         List<Transaction> loadedTransactions = JsonSerializer.Deserialize<List<Transaction>>(json);

    //         if (loadedTransactions != null) {
    //             transactions = loadedTransactions;
    //             return true;
    //         }
    //     } catch (FileNotFoundException) {
    //         Console.WriteLine($"El archivo {Number}.json no existe. Por lo tanto, no hay ninguna transacción guardada.");
    //     } catch (Exception e) {
    //         Console.WriteLine($"Error al cargar las transacciones: {e.Message}");
    //     }
    //     return false;
    // }


}