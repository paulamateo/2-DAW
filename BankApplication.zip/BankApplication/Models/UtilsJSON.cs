using System.Text.Json;
namespace Models;

public class UtilsJSON {

    //GUARDA LAS TRANSACCIONES EN ARCHIVOS JSON (ESCRIBIR)
    public static void SaveJson(string fileName, List<Transaction> transactions) { 
        try {
            string json = JsonSerializer.Serialize(transactions);
            File.WriteAllText(fileName, json);
        }catch (Exception e) {
            Console.WriteLine($"Error al guardar las transacciones: {e.Message}");
        }
    } 

    //CARGAR LAS TRANSACCIONES (LEER)
    public static List<Transaction> LoadJson(string fileName) {
        try {
            string json = File.ReadAllText(fileName);
            List<Transaction> loadedTransactions = JsonSerializer.Deserialize<List<Transaction>>(json);
            return loadedTransactions ?? new List<Transaction>();
        } catch (FileNotFoundException) {
            Console.WriteLine($"El archivo {fileName} no existe. Por lo tanto, no hay ninguna transacción guardada.");
        } catch (Exception e) {
            Console.WriteLine($"Error al cargar las transacciones: {e.Message}");
        }
        return new List<Transaction>();
    }
    

}